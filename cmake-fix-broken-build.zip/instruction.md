# Repair a Regressed CMake Build

I’ve got a small C++ project in `/app` that used to build fine, but after splitting it into `core`, `engine`, `plugin`, and `app`, the CMake setup got messy. The source files themselves are fine; the breakage is in the CMake wiring.

Please fix the build configuration using only `CMakeLists.txt` changes. Don’t edit any `.cpp`, `.h`, or `.in` files.

What I need working again is pretty straightforward from the outside:
- clean out-of-source builds for both `Release` and `Debug`
- clean builds should also work with the `Ninja` generator for both `Release` and `Debug`
- both executables (`myapp` and `selfcheck`) must build and run
- `myapp` should print:

```
text: HELLO
hash: 0x05e918d2
valid: yes
profile: <build type>
```

- `selfcheck` should print:

```
selfcheck: ok (<build type>)
```

The build-profile header should be generated per build type (so Release and Debug runs show the right profile). Also make sure dependency wiring is clean: `core` headers should be exported correctly, and `engine` should declare its dependency on `core` and thread support by using CMake’s Threads package target.

Please keep language standard settings target-scoped (per target compile features) rather than a single global project-wide C++ standard.

One more thing: keep `plugin` as an object-library-style component in the final setup.
