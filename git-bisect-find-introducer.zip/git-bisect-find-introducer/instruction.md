Use `git bisect` in `/app/repo` to track down when a very specific bug marker first appeared.

Somewhere in the history, a developer added a single line to `src/main.py` that is **exactly**:

`BUG_INTRODUCED`

There are also other commits where that string only shows up as part of a longer line (for example `# BUG_INTRODUCED`, `REF: BUG_INTRODUCED`, or `BUG_INTRODUCED ` with extra spaces). Those do **not** count as the introducing change.

Your job:

1. Use `git bisect` to find the **first commit** where `src/main.py` actually contains a whole line that is exactly `BUG_INTRODUCED` and nothing else. Your bisect script or commands should only treat a commit as “bad” when that whole‑line match is present.
2. Once you’ve found the commit, create `/app/answer.txt` with exactly three non‑empty lines:
   - Line 1: the full 40‑character commit hash (lowercase hex).
   - Line 2: the one‑line commit subject (first line of the commit message).
   - Line 3: the author’s email address.
3. Create `/app/report.json` describing the same commit, with these fields:
   - `hash`: must match line 1 of `answer.txt`.
   - `subject`: must match line 2 of `answer.txt`.
   - `author`: must match line 3 of `answer.txt`.
   - `files_touched`: list of file paths changed in that commit (sorted, unique).
   - `bug_line_is_exact`: `true` only if `src/main.py` in that commit really contains the exact standalone `BUG_INTRODUCED` line.

Don’t rewrite history; just inspect it. You can script the bisect and JSON generation however you like, as long as `answer.txt` and `report.json` end up in the right place with the expected contents.

