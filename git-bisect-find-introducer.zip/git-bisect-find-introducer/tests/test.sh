#!/bin/bash

set -euo pipefail

# Ensure reward file exists even if we crash later (avoids RewardFileNotFoundError).
mkdir -p /logs/verifier
echo 0 > /logs/verifier/reward.txt

# Install uv for Python environment isolation (Harbor CI requirement).
apt-get update
apt-get install -y curl
curl -LsSf https://astral.sh/uv/install.sh | sh
source "$HOME/.local/bin/env"

# Run pytest via uvx for Python environment isolation.
uvx --python 3.12 --with pytest==9.0.2 pytest /tests/test_output.py

status=$?

if [ "$status" -eq 0 ]; then
  echo 1 > /logs/verifier/reward.txt
else
  echo 0 > /logs/verifier/reward.txt
fi

exit "$status"
